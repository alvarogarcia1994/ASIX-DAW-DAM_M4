#############
Com ho he fet
#############

Autor: Alvaro Garcia Baena
Data de realitzacio: 31 d'Octubre de 2017

###################
Accions realitzades
###################

1- Crear un nou fitxer
2- Construir la taula
3- Introdüir les dades
4- Guardar el fitxer
5- Obrir un terminal
6- Amb la comanda **$rst2html companys.rst companys.html** realitzo la conversio de rst a html5
7- Amb la comanda **$rst2odt companys.rst companys.odt**
8- Visualitzo ambdos documents
9- Crear aquest fitxer
10- Guardo el fitxer
11- Executo la comanda **$tar czvf elmeuexercici.tar.gz companys. comhohefet.rst** per a empaquetar els 4 fitxers.
12- L'anomeno elmeuexercici.tar.gz
13- El pujo al moodle